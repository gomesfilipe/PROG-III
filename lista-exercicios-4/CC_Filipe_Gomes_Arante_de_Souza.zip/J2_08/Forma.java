package J2_08;

public interface Forma {
	public static final double PI = 3.141592;
	
	double perimetro();
	
	double area();
}
